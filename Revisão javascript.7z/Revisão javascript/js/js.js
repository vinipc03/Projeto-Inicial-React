function media(){
    var nota1 = parseFloat(document.getElementById("nota1").value);
     var nota2 = parseFloat(document.getElementById("nota2").value);
     var resultado = document.getElementById('media')
     var resulfinal = document.getElementById('resultfinal')
     var media = (nota1 + nota2)/2 ;

     resultado.innerHTML = `Media do aluno ${nome.value} é ${media.toFixed(2)}`
     
     if(media >= 6){
        resulfinal.innerHTML = `Aprovado!`
     }else if(media >= 4){
        resulfinal.innerHTML = `IFA`
     } if(media < 4){
        resulfinal.innerHTML = `REPROVADO`
     }
}

function CalcIMC(){
    var peso = parseFloat(document.getElementById("peso").value);
    var altura = parseFloat(document.getElementById("altura").value);
    var resultadofinal = document.getElementById("resultadofinal");
    var imcfinal = document.getElementById("imcfinal");
    var calculoPeso = (peso/(altura*altura));
    

    resultadofinal.innerHTML = `O IMC de ${nome1.value} é de ${calculoPeso.toFixed(2)}`

    if(calculoPeso <= 18.5){
        imcfinal.innerHTML = `MAGREZA`
    }else if(calculoPeso <= 24.9){
        imcfinal.innerHTML = `NORMAL`
    }else if(calculoPeso <= 29.9){
        imcfinal.innerHTML = `SOBREPESO`
    }else if(calculoPeso <= 39.9){
        imcfinal.innerHTML = `OBESIDADE`
    }else if(calculoPeso <= 40){
        imcfinal.innerHTML = `OBESIDADE GRAVE`
    }
}